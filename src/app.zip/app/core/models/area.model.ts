export interface Area {
    code: string;
    msg: string;
    details: string[];
  }