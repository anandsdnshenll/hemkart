import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators} from '@angular/forms';
import { Router, Route, ActivatedRoute } from '@angular/router';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { HeaderService } from 'src/app/header.service';
declare var $: any;

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private activeRoute:ActivatedRoute,
    private spinnerService: Ng4LoadingSpinnerService,private headerService:HeaderService) {
    this.spinnerService.show();
    setTimeout(() => this.spinnerService.hide(),800);
   }
   url:string;
  ngOnInit() {
    this.headerService.setTitle('home');
  }
}
